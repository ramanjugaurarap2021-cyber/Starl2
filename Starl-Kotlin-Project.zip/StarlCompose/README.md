# Starl Android

Android application shell built with Kotlin + Jetpack Compose. The original `Starl4.html` interface is bundled unchanged as a local asset and displayed in Android WebView so its layout, typography, colors, player, settings, navigation and existing interactions remain visually identical. A small Orion-inspired motion layer adds spring-like press feedback and staggered reveal transitions without redesigning the interface.

## Local music
Use Settings → Local music → Add files / Add folder. Android's document picker passes selected audio files to the original Starl local-music UI. Playback and album-art handling are implemented by the original HTML/JavaScript player.

## Build
Open `StarlCompose` as an Android Gradle project or run `gradle assembleDebug` from that directory. GitHub Actions workflow is in `.github/workflows/android.yml`.

## Important implementation note
This approach deliberately hosts the original HTML inside a Compose Android shell to preserve the UI exactly; it is not a full rewrite of every HTML component into native Compose widgets.
