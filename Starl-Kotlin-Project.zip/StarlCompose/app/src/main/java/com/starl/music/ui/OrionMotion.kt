package com.starl.music.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.scale

/** Orion-inspired expressive press squash; visual layout and colors remain owned by Starl. */
fun Modifier.orionPress(onClick: () -> Unit): Modifier = composed {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) .94f else 1f, spring(stiffness = Spring.StiffnessMediumLow), label = "orion-press")
    this.scale(scale).clickable { onClick() }
}
