package com.starl.music.player

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.starl.music.data.AudioTrack

class PlaybackController(context: Context) {
    val player: ExoPlayer = ExoPlayer.Builder(context).build()

    fun playQueue(tracks: List<AudioTrack>, startIndex: Int) {
        player.setMediaItems(tracks.map { MediaItem.fromUri(it.contentUri) }, startIndex, 0L)
        player.prepare()
        player.playWhenReady = true
    }

    fun play(track: AudioTrack) {
        player.setMediaItem(MediaItem.fromUri(track.contentUri))
        player.prepare()
        player.play()
    }

    fun release() = player.release()
}
