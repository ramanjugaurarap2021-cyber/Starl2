package com.starl.music.ui

import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.layout.ContentScale
import com.starl.music.data.AudioTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun AlbumArtwork(track: AudioTrack?, modifier: Modifier = Modifier, radius: Int = 14) {
    val context = LocalContext.current
    val bitmap = produceState<android.graphics.Bitmap?>(null, track?.id) {
        value = withContext(Dispatchers.IO) {
            if (track == null) null else try {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, track.contentUri)
                    retriever.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
                } finally { retriever.release() }
            } catch (_: Exception) { null }
        }
    }.value
    Box(modifier.clip(RoundedCornerShape(radius.dp)).background(Brush.linearGradient(listOf(Color(0xFF704C78), Color(0xFF263C62)))), contentAlignment = Alignment.Center) {
        if (bitmap != null) Image(bitmap.asImageBitmap(), contentDescription = "${track?.album ?: "Album"} artwork", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Default.MusicNote, contentDescription = "No album artwork", tint = Color.White.copy(.8f))
    }
}
